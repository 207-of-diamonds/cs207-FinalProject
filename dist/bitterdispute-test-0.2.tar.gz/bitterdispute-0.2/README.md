# cs207-FinalProject
Final Project for CS207: Automatic Differentiation

# Group 31
# Members
- Selina Wu
- Stephanie Zhang
- Will Seaton
- Caroline Stedman


[![Build Status](https://travis-ci.org/207-of-diamonds/cs207-FinalProject.svg?branch=master)](https://travis-ci.org/207-of-diamonds/cs207-FinalProject)

[![codecov](https://codecov.io/gh/207-of-diamonds/cs207-FinalProject/branch/master/graph/badge.svg)](https://codecov.io/gh/207-of-diamonds/cs207-FinalProject)

